module.exports = [
    {
      place: "Meridian, Idaho",
      price: 100,
      timeToGo: "Summer",
      _id: '9349asefd85'
    },{
      place: "Cancun",
      price: 333,
      timeToGo: "Summer",
      _id: '394sdf7895'
    },{
      place: "China",
      price: 1200,
      timeToGo: "Fall",
      _id: '34ou53ksjdjkhf'
    },{
      place: "Russia",
      price: 1100,
      timeToGo: "Summer",
      _id: 'alksdfas847874'
    },{
      place: "Lebanon",
      price: 400,
      timeToGo: "Spring",
      _id: '9345897jksdfhjkl'
    }
  ]


  